// project_instructions.md placeholder
