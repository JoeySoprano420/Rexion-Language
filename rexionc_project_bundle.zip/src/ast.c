// ast.c placeholder
