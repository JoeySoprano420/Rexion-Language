// utils.c placeholder
